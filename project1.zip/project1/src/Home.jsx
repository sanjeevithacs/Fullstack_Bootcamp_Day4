//    DAY-5
//Static Route


// import React from 'react'

// function Home() {
//   return (
//     <div>Home</div>
//   )
// }

// export default Home







// //form form component - learn css before this

// import Form from './Form'
// import React from 'react'

// function Home() {
//   return (
//     <div>
//      {/* <Form/> */}
//      <form>
//       <label> Email</label>
//       <input type='text'></input>
//       <label>Password</label>
//       <input type='text'></input>
//      </form>
//     </div>
//   )
// }

// export default Home







// // TAILWIND CSS - refer website 

// import React from 'react'

// function Home() {
//   return (
// <div>
//     {/* Teal background, width 10, height 20 with shadow */}
//     <h1 className="bg-teal-500 w-10 h-20 shadow-lg shadow-teal-700">
//         hello
//     </h1>

//     {/* Serif font, size 2xl, bold with transition */}
//     <h1 className="font-serif text-2xl font-bold transition duration-500 ease-in-out transform hover:scale-110">
//         hello123
//     </h1>

//     {/* Slate color, overline, sky decoration with blur */}
//     <h1 className="text-slate-400 overline decoration-sky-600 blur-sm hover:blur-none">
//         hello114
//     </h1>
// <br></br>
//     {/* Teal background, rounded, dotted border with combined styles */}
//     <h1 className="bg-teal-500 w-10 h-20 rounded-lg border-dotted border-2 border-sky-500 shadow-2xl shadow-indigo-600 rotate-12 blur-sm transition duration-700 ease-in-out hover:rotate-0 hover:blur-none">
//         hello
//     </h1>
// <br/>
//     <h1 className='bg-rose-400 w-20 h-20 font-serif text-4xl font-extrabold text-zinc-950 underline decoration-pink-700 rounded-lg ring-1 border-4 border-sky-950 shadow-md shadow-stone-500 opacity-500 blur-s hover:rotate-90 transition-all delay-150'>hii</h1>
// </div>



//   )
// }

// export default Home








// import React from 'react'

// function Home() {
//   return (
//  <div className='h-screen  bg-violet-400 flex justify-start  items-start'>
// <div className='h-80 w-screen bg-black text-white m-10 rounded-lg flex-col '>
//     <div className='bg-slate-400'>1</div>
//     <div className='bg-orange-300 order-3'>2</div>
//     <div className='bg-slate-600'>3</div>
//     <div className='bg-orange-500'>4</div>
//     <div className='bg-slate-700'>5</div>
// </div>
// </div>  

//   )
// }

// export default Home




// import React from 'react'

// function Home() {
//   return (
// <div className='lg:bg-pink-500 md:bg-yellow-500 sm:bg-green-500 bg-blue-500'>Home</div>
//   )
// }

// export default Home











// //form form component - learn css before this

import Form from './Form'
import React from 'react'

function Home() {
  return (
    <div>
     <Form/> 
    
    </div>
  )
}

export default Home

